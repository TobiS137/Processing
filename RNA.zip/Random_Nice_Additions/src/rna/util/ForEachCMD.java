package rna.util;

import java.util.ArrayList;

@FunctionalInterface
public interface ForEachCMD <T>{
	public void run(T item);
}
