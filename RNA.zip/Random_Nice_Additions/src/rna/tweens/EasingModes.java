package rna.tweens;

public enum EasingModes {
	IN, OUT, IN_OUT;
}